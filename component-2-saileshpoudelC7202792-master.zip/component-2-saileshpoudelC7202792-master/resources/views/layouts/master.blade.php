<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>CRUD Application in Laravel with JSON</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <link rel="stylesheet" href="{{ asset('frontend/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/css/mdb.min.css') }}">
    <link rel="stylesheet" href="{{ asset('frontend/css/style.css') }}">
    <style>
        .error {
            color: red;
            font-size: 13px;
        }
    </style>
    @yield('styles')
</head>

<body>
    <p class="text-center mt-4 font-weight-bold">Component - 2</p>
    <h1 class="text-center mt-4">CRUD Application with Laravel and JSON</h1>
    @yield('body')
    <script type="text/javascript" src="{{ asset('frontend/js/jquery.min.js') }}">
    </script>
    <script type="text/javascript" src="{{ asset('frontend/js/popper.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('frontend/js/mdb.min.js') }}"></script>
    @yield('scripts')
</body>

</html>
