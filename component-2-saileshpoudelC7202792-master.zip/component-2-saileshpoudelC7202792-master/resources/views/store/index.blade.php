@extends('layouts.master')

@section('body')
<div class="container">
    <a href="{{ route('stores.create') }}" class="btn btn-secondary ml-4 mb-3">Create</a>
    @include('../store/notification/flashMessage')
    <div class="row mt-5">
        @isset($products)
        @foreach ($products as $key => $product)

        {{-- Game --}}
        @if ($product['type'] == 'game')
        <div class="col-md-4">
            @include('store.includes.product-list',['product' => $product])
        </div>
        @endif
        {{-- Game --}}

        {{-- CD --}}
        @if ($product['type'] == 'cd')
        <div class="col-md-4">
            @include('store.includes.product-list',['product' => $product])
        </div>
        @endif
        {{-- CD --}}

        {{-- Book --}}
        @if ($product['type'] == 'book')
        <div class="col-md-4">
            @include('store.includes.product-list',['product' => $product])
        </div>
        @endif
        {{-- Book --}}

        @endforeach
        @endisset
    </div>
</div>
</div>
@endsection
@section('scripts')
<script>
    setTimeout(function () {
        $('.alert').slideUp();
    }, 1500);
</script>
@endsection
