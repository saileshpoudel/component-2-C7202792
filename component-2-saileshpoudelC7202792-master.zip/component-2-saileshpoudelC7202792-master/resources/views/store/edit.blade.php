@extends('layouts.master')
@section('body')
<!-- Material form login -->
<div class="container">
    <div class="row">
        <div class="col-md-6 mt-5 ml-5">
            <div class="card">

                <h5 class="card-header info-color white-text text-center py-4">
                    <strong>Product Update</strong>
                </h5>

                <!--Card content-->
                <div class="card-body px-lg-5 pt-0">

                    <!-- Form -->
                    <form class="text-center" style="color: #757575;" action="{{ route('stores.update',$product['id']) }}"
                        method="POST">
                        @csrf
                        @method('put')

                        <div class="md-form">
                            <select name="producttype" id="producttype" class="form-control">
                                <option value="" selected disabled>--select any one--</option>
                                <option value="game" {{ $product['type'] == 'game' ? 'selected' : '' }}>Game</option>
                                <option value="cd" {{ $product['type'] == 'cd' ? 'selected' : '' }}>CD</option>
                                <option value="book" {{ $product['type'] == 'book' ? 'selected' : '' }}>Book</option>
                            </select>
                            @include('../store/notification/error',['fieldName' => 'producttype'])
                        </div>

                        <!-- Password -->
                        <div class="md-form">
                            <input type="text" id="title" class="form-control" name="title" value="{{ $product['title'] }}">
                            <label for="title">Title</label>
                            @include('../store/notification/error',['fieldName' => 'title'])
                        </div>

                        <div class="md-form">
                            <input type="text" id="fname" class="form-control" name="fname" value="{{ $product['firstname'] }}">
                            <label for="fname">Firstname/SurName(optional)</label>
                            @include('../store/notification/error',['fieldName' => 'fname'])
                        </div>


                        <div class="md-form">
                            <input type="text" id="sname" class="form-control" name="sname" value="{{ $product['mainname'] }}">
                            <label for="sname">Surname/brand</label>
                            @include('../store/notification/error',['fieldName' => 'sname'])
                        </div>



                        <div class="md-form">
                            <input type="number" id="price" class="form-control" name="price" value="{{ $product['price'] }}">
                            <label for="price">Price</label>
                            @include('../store/notification/error',['fieldName' => 'price'])
                        </div>

                        <div class="md-form">
                            <input type="number" id="pages" class="form-control" name="pages" value="{{ $product['numpages'] ?? $product['playlength'] }}">
                            <label for="pages">Pages/PlayLength</label>
                            @include('../store/notification/error',['fieldName' => 'pages'])
                        </div>

                        <!-- Sign in button -->
                        <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0"
                            type="submit">update</button>

                    </form>
                    <!-- Form -->

                </div>

            </div>
            <!-- Material form login -->

        </div>
    </div>
</div>

@endsection
{{--
    "id": 3,
        "type": "game",
        "title": "Game Title",
        "firstname": "game name",
        "sname": "Zandstra",
        "price": 44.99,
        "pages": 608

    --}}
