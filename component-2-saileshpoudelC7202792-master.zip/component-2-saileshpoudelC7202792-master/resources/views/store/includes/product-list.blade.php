<!-- Card -->
<div class="card mt-3">
    <!-- Card image -->
    <div class="view overlay">
        <a href="#!">
            <div class="mask rgba-white-slight"></div>
        </a>
    </div>

    <!-- Card content -->
    <div class="card-body">

        <!-- Title -->
        <h4 class="card-titl  p-3 bg-info text-white text-center font-weight-bold">

            {{ strtoupper($product['type']) }} </h4>
        <!-- Text -->
        <p class="card-text">
            <h5 class="font-weight-bold card-title"><strong>Type</strong> :
                {{ ucfirst($product['type']) }}
            </h5>
            <h5 class="font-weight-bold card-title"><strong>Title</strong> :
                {{ ucfirst($product['title']) }}
            </h5>
            <h5 class="font-weight-bold card-title"><strong>FirstName</strong>
                : {{ ucfirst($product['firstname']) }}
            </h5>
            <h5 class="font-weight-bold card-title"><strong>MainName</strong> :
                {{ ucfirst($product['mainname']) }}
            </h5>
            <h5 class="font-weight-bold card-title"><strong>Price</strong>
                : {{ number_format($product['price'] , 2) }}
            </h5>
            <h5 class="font-weight-bold card-title"><strong>NumPages/PlayLength</strong>
                :
                {{  isset($product['numpages']) ? number_format($product['numpages'], 2) : number_format($product['playlength'], 2) }}
            </h5>
        </p>
        <!-- Button -->
    </div>
    <!-- Card footer -->
    <div class="card-footer text-muted text-center">
        <a href="{{ route('stores.edit', $product['id']) }}" class="btn btn-success float-left btn-amber btn-sm"><i
                class="fas fa-edit"></i></a>

        <form action="{{ route('stores.destroy', $product['id']) }}" method="post"
            onsubmit=" return confirm('Are you sure want to delete.?')">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-info btn-sm float-right"><i class="fas fa-trash"></i></button>
        </form>
    </div>
</div>
<!-- Card -->
