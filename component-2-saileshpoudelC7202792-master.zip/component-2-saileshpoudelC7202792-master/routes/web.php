<?php

use App\Http\Controllers\StoreController;
use Illuminate\Support\Facades\Route;





/**
 * home page
 */
Route::get('/',[StoreController::class ,'index']);

/**
 * store resource
 */
Route::resource('stores', StoreController::class);
