<?php

namespace App\Http\Controllers;

use App\awe\Repository\CRUDJsonRepository;
use App\Http\Requests\StoreCreateRequest;

class StoreController extends Controller
{

    /**
     * @var CRUDJsonRepository
     */
    protected $crudJsonRepository;


    /**
     * StoreController constructor.
     * @param CRUDJsonRepository $crudJsonRepository
     */
    public function __construct(CRUDJsonRepository $crudJsonRepository)
    {
        $this->crudJsonRepository = $crudJsonRepository;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = $this->crudJsonRepository->listOfJsonData();

        if (is_null($products)) return CRUDJsonRepository::redirectTo('error', 'product not found');

        return view('store.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('store.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCreateRequest $request)
    {
        $this->crudJsonRepository->insertJsonData($request);

        return CRUDJsonRepository::redirectTo('success', 'Data Inserted Successfully');
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $jsonProduct = $this->crudJsonRepository->editJsonData($id);

        if (is_null($jsonProduct)) return CRUDJsonRepository::redirectTo('error', 'product not found');

        return view('store.show')
            ->with('product', $jsonProduct);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $jsonProduct = $this->crudJsonRepository->editJsonData($id);

        if (is_null($jsonProduct)) return CRUDJsonRepository::redirectTo('error', 'product not found');

        return view('store.edit')
            ->with('product', $jsonProduct);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StoreCreateRequest $request, $id)
    {
        $this->crudJsonRepository->updateJsonData($request, $id);

        return CRUDJsonRepository::redirectTo('success', 'Data updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->crudJsonRepository->removeJsonData($id);

        return CRUDJsonRepository::redirectTo('success', 'Data Deleted Successfully');
    }
}
