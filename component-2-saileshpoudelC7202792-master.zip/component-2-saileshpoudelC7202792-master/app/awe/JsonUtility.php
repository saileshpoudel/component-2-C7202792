<?php

namespace App\awe;

class JsonUtility
{


    /**
     * @var string $file
     */
    private $file;

    /**
     * @return mixed
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @param mixed $file
     * @return JsonUtility
     */
    public function setFile($file)
    {
        $this->file = $file;
        return $this;
    }


    /**
     * @var int $id
     */
    private $id;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     * @return JsonUtility
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }


    /**
     * @var string $producttype
     */
    private  $producttype;

    /**
     * @return mixed
     */
    public function getProducttype()
    {
        return $this->producttype;
    }

    /**
     * @param mixed $producttype
     * @return JsonUtility
     */
    public function setProducttype($producttype)
    {
        $this->producttype = $producttype;
        return $this;
    }



    /**
     * @var string $fname
     */
    private  $fname;

    /**
     * @return mixed
     */
    public function getFname()
    {
        return $this->fname;
    }

    /**
     * @param mixed $fname
     * @return JsonUtility
     */
    public function setFname($fname)
    {
        $this->fname = $fname;
        return $this;
    }



    /**
     * @var string $sname
     */
    private  $sname;

    /**
     * @return mixed
     */
    public function getSname()
    {
        return $this->sname;
    }

    /**
     * @param mixed $sname
     * @return JsonUtility
     */
    public function setSname($sname)
    {
        $this->sname = $sname;
        return $this;
    }


    /**
     * @var string $title
     */
    private  $title;

    /**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param mixed $title
     * @return JsonUtility
     */
    public function setTitle($title)
    {
        $this->title = $title;
        return $this;
    }


    /**
     * @var int $pages
     */
    private  $pages;

    /**
     * @return mixed
     */
    public function getPages()
    {
        return $this->pages;
    }

    /**
     * @param mixed $pages
     * @return JsonUtility
     */
    public function setPages($pages)
    {
        $this->pages = $pages;
        return $this;
    }




    /**
     * @var float price
     */
    private  $price;

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @param mixed $price
     * @return JsonUtility
     */
    public function setPrice($price)
    {
        $this->price = $price;
        return $this;
    }



    public static function makeProductArray(string $file)
    {
        $string = file_get_contents($file);

        $productsJson = json_decode($string, true);


        $products = [];
        foreach ($productsJson as $product) {
            switch ($product['type']) {
                case "cd":
                    $cdproduct = new \App\Awe\CdProduct(
                        $product['id'],
                        $product['title'],
                        $product['firstname'],
                        $product['mainname'],
                        $product['price'],
                        $product['playlength']
                    );
                    $products[] = $cdproduct;
                    break;

                case "book":
                    $bookproduct = new \App\Awe\BookProduct(
                        $product['id'],
                        $product['title'],
                        $product['firstname'],
                        $product['mainname'],
                        $product['price'],
                        $product['numpages']
                    );
                    $products[] = $bookproduct;
                    break;

                case "game":
                    $bookproduct = new \App\Awe\GameProduct(
                        $product['id'],
                        $product['title'],
                        $product['firstname'],
                        $product['mainname'],
                        $product['price'],
                        $product['numpages']
                    );
                    $products[] = $bookproduct;
                    break;
            }
        }
        return $products;
    }

    /**
     * update product
     */

    public  function updateProduct()
    {
        //read file
        $data = file_get_contents($this->getFile());

        // decode json to array
        $json_arr = json_decode($data, true);

        foreach ($json_arr as $key => $value) {

            if ($value['id'] ==  $this->getId()) {

                $json_arr[$key]['type'] =  $this->getProducttype();
                $json_arr[$key]['title'] = $this->getTitle();
                $json_arr[$key]['firstname'] = $this->getFname();
                $json_arr[$key]['mainname'] = $this->getSname();
                $json_arr[$key]['price'] = $this->getPrice();
                if ($this->getProducttype() == 'cd') $json_arr[$key]['playlength'] = $this->getPages();
                if ($this->getProducttype() == 'book') $json_arr[$key]['numpages'] = $this->getPages();
                if ($this->getProducttype() == 'game') $json_arr[$key]['numpages'] = $this->getPages();
            }
        }

        // encode array to json and save to file
        file_put_contents($this->getFile(), json_encode($json_arr));
    }



    /**
     * get single product details
     */

    public  function getProductId()
    {
        $string = file_get_contents($this->getFile());

        $productsJson = json_decode($string, true);

        $product = [];

        foreach ($productsJson as  $product) {
            if ($product['id'] == $this->getId())  return  $product;
        }
    }


    /**
     * delete product
     */
    public  function deleteProduct()
    {
        $string = file_get_contents($this->getFile());

        $productsJson = json_decode($string, true);

        $products = [];
        foreach ($productsJson as $product) {
            if ($product['id'] != $this->getId()) {
                $products[] = $product;
            }
        }
        $json = json_encode($products);
        file_put_contents($this->getFile(), $json);
    }


    /**
     * add new product
     */
    public function addNewProduct()
    {
        $string = file_get_contents($this->getFile());


        $productsJson = json_decode($string, true);

        $ids = [];
        foreach ($productsJson as $product) {
            $ids[] = $product['id'];
        }
        rsort($ids);
        $newId = $ids[0] + 1;

        $products = [];
        foreach ($productsJson as $product) {
            $products[] = $product;
        }

        $newProduct = [];
        $newProduct['id'] = $newId;
        $newProduct['type'] = $this->getProducttype();
        $newProduct['title'] = $this->getTitle();
        $newProduct['firstname'] = $this->getFname();
        $newProduct['mainname'] = $this->getSname();
        $newProduct['price'] = $this->getPrice();

        if ($this->getProducttype() == 'cd') $newProduct['playlength'] = $this->getPages();
        if ($this->getProducttype() == 'book') $newProduct['numpages'] = $this->getPages();
        if ($this->getProducttype() == 'game') $newProduct['numpages'] = $this->getPages();

        $products[] = $newProduct;

        $json = json_encode($products);

        file_put_contents($this->getFile(), $json);
    }
}
