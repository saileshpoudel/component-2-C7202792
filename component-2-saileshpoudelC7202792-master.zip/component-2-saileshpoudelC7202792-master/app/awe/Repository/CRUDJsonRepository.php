<?php

namespace App\awe\Repository;

use App\awe\JsonUtility;

class CRUDJsonRepository implements CRUDStrategy
{

    /**
     * @var JsonUtility
     */
    protected $jsonResource;


    /**
     * CRUDJsonRepository constructor.
     * @param JsonUtility $jsonResource
     */
    public function __construct(JsonUtility $jsonResource)
    {
        $this->jsonResource = $jsonResource;
    }


    /**
     * @return mixed
     */
    public function listOfJsonData()
    {
        return json_decode(file_get_contents(config('services.json.path')), true);
    }


    /**
     * @param $request
     * @return mixed|void
     */
    public function insertJsonData($request)
    {
        $data = $request->all();

        $this->jsonResource->setFile(config('services.json.path'));

        $this->jsonResource->setProducttype($data['producttype']);

        $this->jsonResource->setFname($data['fname']);

        $this->jsonResource->setSname($data['sname']);

        $this->jsonResource->setTitle($data['title']);

        $this->jsonResource->setPages($data['pages']);

        $this->jsonResource->setPrice($data['price']);

        $this->jsonResource->addNewProduct();
    }

    /**
     * @param int $id
     * @return mixed
     */
    public function editJsonData($id)
    {
        $this->jsonResource->setFile(config('services.json.path'));

        $this->jsonResource->setId($id);

        $product = $this->jsonResource->getProductId();

        return $product;
    }


    /**
     * @param $request
     * @param int $id
     * @return mixed|void
     */
    public function updateJsonData($request, $id)
    {
        $data = $request->all();

        $this->jsonResource->setId($id);

        $this->jsonResource->setFile(config('services.json.path'));

        $this->jsonResource->setProducttype($data['producttype']);

        $this->jsonResource->setFname($data['fname']);

        $this->jsonResource->setSname($data['sname']);

        $this->jsonResource->setTitle($data['title']);

        $this->jsonResource->setPages($data['pages']);

        $this->jsonResource->setPrice($data['price']);

        $this->jsonResource->updateProduct();
    }


    /**
     * @param int $id
     * @return mixed|void
     */
    public  function removeJsonData($id)
    {
        $this->jsonResource->setFile(config('services.json.path'));

        $this->jsonResource->setId($id);

        $this->jsonResource->deleteProduct();
    }

    /**
     * @param string $key
     * @param  string $message
     * @return \Illuminate\Http\RedirectResponse|mixed
     */
    public static function redirectTo($key, $message)
    {
        return redirect()->route('stores.index')
            ->with($key, $message);
    }
}
