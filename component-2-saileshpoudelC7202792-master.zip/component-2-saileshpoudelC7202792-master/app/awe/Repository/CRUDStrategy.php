<?php

namespace App\awe\Repository;


/**
 * Interface CRUDStrategy
 * @package App\awe\Repository
 */
interface CRUDStrategy
{

    /**
     * @return mixed
     */
    public function listOfJsonData();

    /**
     * @param $request
     * @return mixed
     */
    public function insertJsonData($request);

    /**
     * @param $request
     * @param $id
     * @return mixed
     */
    public function updateJsonData($request, $id);

    /**
     * @param $id
     * @return mixed
     */
    public function removeJsonData($id);

    /**
     * @param $id
     * @return mixed
     */
    public function editJsonData($id);

    /**
     * @param $key
     * @param $message
     * @return mixed
     */
    public static function redirectTo($key, $message);


}
