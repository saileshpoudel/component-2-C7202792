# Welcome To CRUD Application in Laravel with JSON 

 CRUD application with json file to store data on it. In this application materialize css where used to look interative UI Design.

## List Of Products
 
<img width="1440" alt="ListOfProducts" src="https://user-images.githubusercontent.com/41099324/101626727-7d0b9e80-3a45-11eb-981f-5ff1588105a7.JPG">


## Create New Product
<img width="1440" alt="createNewProduct" src="https://user-images.githubusercontent.com/41099324/101626788-8bf25100-3a45-11eb-8775-52e4fa360f31.JPG">
